package com.test.testcases;

import com.test.utils.TestUtil;

public class Test {

	public static void main(String[] args) {
		
		String str = TestUtil.getRandomString(10);
		System.out.println(str);
		//0F7H8C9JRTOCYAUPX7
		//9PQXBHG6JA1ADOMC88
		//LHTXVNV3K4X2WOCCE3
	}

}
