/**
 * 
 */
package com.test.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.test.pages.LoginPage;
import com.test.utils.PropertiesCache;
import com.test.utils.TestInitializer;

/**
 * @author Tushar.Gulve
 *
 */
public class LoginTest extends TestInitializer {

	public static final PropertiesCache cache = PropertiesCache.getInstance();

	@Test(description = "To check whether user logs in successfully or not")
	public static void login() throws InterruptedException {

		LoginPage login = new LoginPage(driver);
		login.login(cache.getProperty("email"), cache.getProperty("password"));
		Thread.sleep(5000);
		
		String actMsg = "Signed in successfully.";
		String expMsg = login.getloginSuccessMsg();
		
		Assert.assertEquals(actMsg, expMsg, "Log In Failed...");
		log.info(actMsg);
	}

}
