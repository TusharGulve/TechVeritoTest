/**
 * 
 */
package com.test.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.test.utils.TestInitializer;
import com.test.utils.TestUtil;

/**
 * @author Tushar.Gulve
 *
 */
public class AddNewProductPage extends TestInitializer {

	static WebDriver driver;

	public AddNewProductPage(WebDriver driver) {

		AddNewProductPage.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = ProductElements.productLink_xpath)
	public WebElement productLink;

	@FindBy(how = How.XPATH, using = ProductElements.newProductLink_xpath)
	public WebElement newProductLink;

	@FindBy(how = How.ID, using = ProductElements.AddNewProductElements.title_id)
	public WebElement Title;

	@FindBy(how = How.ID, using = ProductElements.AddNewProductElements.sku_id)
	public WebElement Sku;

	@FindBy(how = How.ID, using = ProductElements.AddNewProductElements.description_id)
	public WebElement Description;

	@FindBy(how = How.ID, using = ProductElements.AddNewProductElements.createProductBtn_id)
	public WebElement createProductBtn;

	@FindBy(how = How.XPATH, using = ProductElements.AddNewProductElements.cancelBtn_xpath)
	public WebElement cancelBtn;

	@FindBy(how = How.XPATH, using = ProductElements.AddNewProductElements.blankTitleErrorMsg_xpath)
	public WebElement TitleValidationMsg;

	@FindBy(how = How.XPATH, using = ProductElements.AddNewProductElements.blankSkuErrorMsg_xpath)
	public WebElement SkuValidationMsg;

	@FindBy(how = How.XPATH, using = ProductElements.AddNewProductElements.blankDescriptionErrorMsg_xpath)
	public WebElement DescValidationMsg;

	@FindBy(how = How.XPATH, using = ProductElements.actTitle_xpath)
	public WebElement TitleOnList;

	@FindBy(how = How.XPATH, using = ProductElements.actSku_xpath)
	public WebElement SkuOnList;

	@FindBy(how = How.XPATH, using = ProductElements.actDesc_xpath)
	public WebElement DescOnList;

	// Click on product link to open product page
	public void clickOnProductLink() {

		productLink.click();
		log.info("Clicked on Product Link on Dashboard");
	}

	// Click on new product button to add new product
	public void clickOnNewProductBtn() {

		TestUtil.explicitWait(newProductLink);
		newProductLink.click();
		log.info("Clicked on New Product Button");
	}

	// Enter title
	public void enterTitle(String title) {

		TestUtil.explicitWait(Title);
		Title.sendKeys(title);
		log.info("Enterred title...");
	}

	// Enter Sku
	public void enterSku(String sku) {

		Sku.sendKeys(sku);
		log.info("Enterred sku...");
	}

	// Enter Description
	public void enterDescription(String desc) {

		Description.sendKeys(desc);
		log.info("Enterred description...");
	}

	// Click on create product button
	public void clickOnCreateProductBtn() {

		createProductBtn.click();
		log.info("Clicked on Create Product Button");
	}

	// Click on cancel button
	public void clickOnCancelBtn() {

		cancelBtn.click();
		log.info("Clicked on Cancel Button");
	}

	// Verify Mandatory fields validation messages
	public void validateMandatoryFieldErrorMsg() {

		TestUtil.explicitWait(TitleValidationMsg);
		String msg = "can't be blank";
		TestUtil.validateErrorMessage(TitleValidationMsg, msg);
		TestUtil.validateErrorMessage(SkuValidationMsg, msg);
		TestUtil.validateErrorMessage(DescValidationMsg, msg);
		log.info("Mandatory fields messages for Title, Sku & Description are verified successfully.");
	}

	// Validating unique title validation message
	public String validateUniqTitleErrorMsg() {

		TestUtil.explicitWait(TitleValidationMsg);
		String errorMsg = TitleValidationMsg.getText();
		return errorMsg;
	}

	// Validating unique Sku validation message
	public String validateUniqSkuErrorMsg() {

		String errorMsg = SkuValidationMsg.getText();
		return errorMsg;
	}

	// Method for redirecting to create product page
	public void redirectToaddProductPage() {

		clickOnProductLink();
		clickOnNewProductBtn();
		clickOnCreateProductBtn();
	}

	// Method for product creation
	public void addProduct(String title, String sku, String desc) throws InterruptedException {

		enterTitle(title);
		enterSku(sku);
		enterDescription(desc);
		clickOnCreateProductBtn();
		Thread.sleep(5000);
	}

	// Captured the value of title
	public String getTitle() {

		String str = TitleOnList.getText();
		return str;
	}

	// Captured the value of sku
	public String getSku() {

		String str = SkuOnList.getText();
		return str;
	}

	// Captured the value of description
	public String getDesc() {

		String str = DescOnList.getText();
		return str;
	}

}
