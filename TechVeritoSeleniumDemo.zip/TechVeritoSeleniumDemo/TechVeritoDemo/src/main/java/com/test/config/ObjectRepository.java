/**
 * 
 */
package com.test.config;

/**
 * @author Tushar.Gulve
 *
 */
public class ObjectRepository {

	protected static class LoginScreenElements {
		/**
		 * Login page item locator
		 */
		public static final String email_id = "admin_user_email";
		public static final String password_id = "admin_user_password";
		public static final String loginBtn_id = "admin_user_submit_action";
		public static final String successLoginMsg_xpath = "//div[@class='flash flash_notice']";
		public static final String logOutButton_xpath = "//a[contains(text(),'Logout')]";

	}

	protected static class ProductElements {
		/**
		 * Product page item locator
		 */
		public static final String productLink_xpath = "//a[contains(text(),'Products')]";
		public static final String newProductLink_xpath = "//a[contains(text(),'New Product')]";

		public static final String actTitle_xpath = "//tr[@class='row row-title']/td";
		public static final String actSku_xpath = "//tr[@class='row row-sku']/td";
		public static final String actDesc_xpath = "//tr[@class='row row-description']/td";

		public static class AddNewProductElements {
			/**
			 * New Product page item locator
			 */
			public static final String title_id = "product_title";
			public static final String sku_id = "product_sku";
			public static final String description_id = "product_description";
			public static final String createProductBtn_id = "product_submit_action";
			public static final String cancelBtn_xpath = "//a[contains(text(),'Cancel')]";

			public static final String blankTitleErrorMsg_xpath = "//li[1]//p[1]";
			public static final String blankSkuErrorMsg_xpath = "//li[2]//p[1]";
			public static final String blankDescriptionErrorMsg_xpath = "//li[3]//p[1]";
		}
	}

	protected static class ProductListingElements {
		/**
		 * Product Listing page item locator
		 */

		public static final String listTitle_xpath = "//tr[1]//td[3]";
		public static final String listSku_xpath = "//tr[1]//td[4]";
		public static final String listDesc_xpath = "//tr[1]//td[5]";

		public static final String viewBTn_xpath = "//tr[1]//td[8]//div[1]//a[1]";
		public static final String editBTn_xpath = "//tr[1]//td[8]//div[1]//a[2]";
		public static final String deleteBTn_xpath = "//tr[1]//td[8]//div[1]//a[3]";

		public static final String deleteProductSuccessMsg_xpath = "//div[@class='flash flash_notice']";

		public static class ViewProductElements {

			public static final String viewTitle_xpath = "//tr[@class='row row-title']/td";
			public static final String viewSku_xpath = "//tr[@class='row row-sku']/td";
			public static final String viewDesc_xpath = "//tr[@class='row row-description']/td";
		}

		public static class EditProductElements {

			public static final String updateTitle_xpath = "//input[@name='product[title]']";
			public static final String updateSku_xpath = "//input[@name='product[sku]']";
			public static final String updateDesc_xpath = "//input[@name='product[description]']";
			public static final String updateBtn_xpath = "//input[@name='commit']";
		}

	}

}
