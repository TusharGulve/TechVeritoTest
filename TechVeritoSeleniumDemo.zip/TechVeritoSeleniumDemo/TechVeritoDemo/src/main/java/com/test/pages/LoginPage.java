/**
 * 
 */
package com.test.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.test.utils.TestInitializer;
import com.test.utils.TestUtil;

/**
 * @author Tushar.Gulve
 *
 */
public class LoginPage extends TestInitializer {

	static WebDriver driver;

	public LoginPage(WebDriver driver) {

		LoginPage.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.ID, using = LoginScreenElements.email_id)
	public WebElement username;

	@FindBy(how = How.ID, using = LoginScreenElements.password_id)
	public WebElement password;

	@FindBy(how = How.ID, using = LoginScreenElements.loginBtn_id)
	public WebElement loginBtn;
	
	@FindBy(how = How.XPATH, using = LoginScreenElements.successLoginMsg_xpath)
	public WebElement successLoginMsg;
	
	@FindBy(how = How.XPATH, using = LoginScreenElements.logOutButton_xpath)
	public WebElement logOutButton;


	//Enter the value of email
	public void enterEmail(String email) {

		TestUtil.explicitWait(username);
		username.sendKeys(email);
		log.info("Username enterred.");
	}

	//Enter the value of password
	public void enterPassword(String pass) {

		password.sendKeys(pass);
		log.info("Password enterred.");
	}

	//Click on login button
	public void clickOnLoginBtn() {

		loginBtn.submit();
		log.info("Clicked on login button");
	}

	//login method
	public void login(String email, String pass) throws InterruptedException {

		enterEmail(email);
		enterPassword(pass);
		clickOnLoginBtn();
		TestUtil.explicitWait(successLoginMsg);

	}
	
	//To capture login success message
	public String getloginSuccessMsg() {

		String str = TestUtil.getValue(successLoginMsg);
		return str;
	}
	
	//click on log out button
	public void logout() throws InterruptedException {

		try {
			logOutButton.click();
			log.info("Clicked on logout button");
		} catch (Exception e) {
			log.info("Exception occured while cliking on logout button " + e);
		}

	}

}
