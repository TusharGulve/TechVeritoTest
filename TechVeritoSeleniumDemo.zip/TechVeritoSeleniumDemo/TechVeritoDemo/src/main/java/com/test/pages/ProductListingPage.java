/**
 * 
 */
package com.test.pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.test.utils.TestInitializer;
import com.test.utils.TestUtil;

/**
 * @author Tushar.Gulve
 *
 */
public class ProductListingPage extends TestInitializer {

	static WebDriver driver;

	public ProductListingPage(WebDriver driver) {

		ProductListingPage.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = ProductElements.productLink_xpath)
	public WebElement productLink;

	@FindBy(how = How.XPATH, using = ProductListingElements.listTitle_xpath)
	public WebElement listTitle;

	@FindBy(how = How.XPATH, using = ProductListingElements.listSku_xpath)
	public WebElement listSku;

	@FindBy(how = How.XPATH, using = ProductListingElements.listDesc_xpath)
	public WebElement listDesc;

	@FindBy(how = How.XPATH, using = ProductListingElements.viewBTn_xpath)
	public WebElement viewAction;

	@FindBy(how = How.XPATH, using = ProductListingElements.editBTn_xpath)
	public WebElement editAction;

	@FindBy(how = How.XPATH, using = ProductListingElements.deleteBTn_xpath)
	public WebElement deleteAction;

	@FindBy(how = How.XPATH, using = ProductListingElements.ViewProductElements.viewTitle_xpath)
	public WebElement viewTitle;

	@FindBy(how = How.XPATH, using = ProductListingElements.ViewProductElements.viewSku_xpath)
	public WebElement viewSku;

	@FindBy(how = How.XPATH, using = ProductListingElements.ViewProductElements.viewDesc_xpath)
	public WebElement viewDesc;

	@FindBy(how = How.XPATH, using = ProductListingElements.EditProductElements.updateTitle_xpath)
	public WebElement updateTitle;

	@FindBy(how = How.XPATH, using = ProductListingElements.EditProductElements.updateSku_xpath)
	public WebElement updateSku;

	@FindBy(how = How.XPATH, using = ProductListingElements.EditProductElements.updateDesc_xpath)
	public WebElement updateDesc;

	@FindBy(how = How.XPATH, using = ProductListingElements.EditProductElements.updateBtn_xpath)
	public WebElement updateBtn;
	
	@FindBy(how = How.XPATH, using = ProductListingElements.deleteProductSuccessMsg_xpath)
	public WebElement deleteProductSuccessMsg;
	

	//Click on Product link
	public void clickOnProductLink() {

		productLink.click();
		log.info("Clicked on Product Link on Dashboard");
		TestUtil.explicitWait(listTitle);
	}

	//Click on View product
	public void clickOnViewLink() {

		viewAction.click();
		log.info("Clicked on view Product.");
		TestUtil.explicitWait(viewTitle);
	}

	//Click on update product
	public void clickOnEditLink() {

		editAction.click();
		log.info("Clicked on edit Product.");
		TestUtil.explicitWait(updateTitle);
	}

	//Click on delete product
	public void clickOnDeleteLink() {

		deleteAction.click();
		log.info("Clicked on delete product link");
	}
	
	//Click on ok button to confirm product deletion
	public void confirmDelete() {

		Alert alert = driver.switchTo().alert();
		alert.accept();
		log.info("Clicked on ok button to delete product");
	}
	
	//Delete Product Method
	public void deleteProduct() {
		
		clickOnDeleteLink();
		confirmDelete();
	}
	
	//Captured Product delete success message
	public String confirmDelProductMsg() {
		
		String str = deleteProductSuccessMsg.getText();
		return str;
	}

	// Get Values of title, sku and description from Single product view
	public String getViewTitle() {

		String str = TestUtil.getValue(viewTitle);
		return str;
	}

	public String getViewSku() {

		String str = TestUtil.getValue(viewSku);
		return str;
	}

	public String getViewDesc() {

		String str = TestUtil.getValue(viewDesc);
		return str;
	}

	// Get Values of title, sku and description from List product view
	public String getListTitle() {

		String str = TestUtil.getValue(listTitle);
		return str;
	}

	public String getListSku() {

		String str = TestUtil.getValue(listSku);
		return str;
	}

	public String getListDesc() {

		String str = TestUtil.getValue(listDesc);
		return str;
	}
	
	// Update title, sku and description
	public void enterTitle(String str) {

		updateTitle.clear();
		updateTitle.sendKeys(str);
		log.info("Title Updated");
	}

	public void enterSku(String str) {
		
		updateSku.clear();
		updateSku.sendKeys(str);
		log.info("Sku Updated");
	}
	
	public void enterDesc(String str) {

		updateDesc.clear();
		updateDesc.sendKeys(str);
		log.info("Description Updated");
	}
	
	//Update Product method
	public void updateProduct(String title, String sku, String desc) {
		
		
		enterTitle(title);
		enterSku(sku);
		enterDesc(desc);
		updateBtn.click();
		TestUtil.explicitWait(viewTitle);
	}

}
