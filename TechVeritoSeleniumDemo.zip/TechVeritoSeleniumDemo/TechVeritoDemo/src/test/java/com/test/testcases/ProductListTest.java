/**
 * 
 */
package com.test.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.test.pages.ProductListingPage;
import com.test.utils.TestInitializer;

/**
 * @author Tushar.Gulve
 *
 */
public class ProductListTest extends TestInitializer {

	@Test(description = "To view product details.", enabled = true)
	public void viewProductDetails() throws InterruptedException {

		// login to application
		LoginTest.login();

		// Click On Product Link
		ProductListingPage product = new ProductListingPage(driver);
		product.clickOnProductLink();

		// Captured Actual Product Details from Product List
		String actTitle = product.getListTitle();
		String actSku = product.getListSku();
		String actDesc = product.getListDesc();

		// Click on View Product Details
		product.clickOnViewLink();

		// Captured Expected Product Details present on view product details page.
		String expTitle = product.getViewTitle();
		String expSku = product.getViewSku();
		String expDesc = product.getViewDesc();

		// Verifying product details present on product list and view product page.
		Assert.assertEquals(actTitle, expTitle, "Product Title does not matched.");
		Assert.assertEquals(actSku, expSku, "Product Sku does not matched.");
		Assert.assertEquals(actDesc, expDesc, "Product Description does not matched.");
		log.info("All product details present properly.");
	}

	@Test(dependsOnMethods = "viewProductDetails", description = "To verify product details update.", enabled = true)
	public void updateProductDetails() throws InterruptedException {

		// Redirect to product details page.
		ProductListingPage product = new ProductListingPage(driver);
		product.clickOnProductLink();

		// Values of product before updating
		String Title = product.getListTitle().substring(0, 10);
		String Sku = product.getListSku().substring(0, 10);
		String Desc = product.getListDesc();

		// Update Product Details
		product.clickOnEditLink();
		product.updateProduct(Title, Sku, Desc);

		// Actual Values of product after updating
		String actTitle = product.getViewTitle();
		String actSku = product.getViewSku();
		String actDesc = product.getViewDesc();

		// Verifying updated product details
		Assert.assertEquals(actTitle, Title);
		Assert.assertEquals(actSku, Sku);

		// Verifying product details present on product list and view product page.
		Assert.assertEquals(actTitle, Title, "Product Title does not matched.");
		Assert.assertEquals(actSku, Sku, "Product Sku does not matched.");
		Assert.assertEquals(actDesc, Desc, "Product Description does not matched.");
		
		log.info("Product Details updated successfully.");

	}

	@Test(dependsOnMethods = "viewProductDetails", description = "To verify product delete functionality", enabled = true)
	public void deleteProduct() throws InterruptedException {

		// Redirect to product details page.
		ProductListingPage product = new ProductListingPage(driver);
		product.clickOnProductLink();

		// Delete Product from list
		product.deleteProduct();

		String actMsg = product.confirmDelProductMsg();
		String expMsg = "Product was successfully destroyed.";
		
		Assert.assertEquals(actMsg, expMsg, "Product not deleted.");
		log.info("Product Deleted Successfully.");

	}
}
