/**
 * 
 */
package com.test.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.test.pages.AddNewProductPage;
import com.test.pages.ProductListingPage;
import com.test.utils.TestInitializer;
import com.test.utils.TestUtil;

/**
 * @author Tushar.Gulve
 *
 */
public class AddNewProductTest extends TestInitializer {

	@Test(description = "To check product creation with mandatory fields.", enabled = true)
	public void addNewProductWithMandatoryFields() throws InterruptedException {

		// login to application
		LoginTest.login();

		AddNewProductPage add = new AddNewProductPage(driver);

		// redirect to add product page
		add.redirectToaddProductPage();

		// click on create product button first to find mandatory fields
		add.clickOnCreateProductBtn();

		// Verifying mandatory field messages
		add.validateMandatoryFieldErrorMsg();

		String title = TestUtil.getRandomString(10);
		String sku = TestUtil.getRandomString(10);
		String desc = TestUtil.getRandomString(10);

		// Creating product by adding mandatory fields
		add.addProduct(title, sku, desc);

		// Capture details of product added
		String actTitle = add.getTitle();
		String actSku = add.getSku();
		String actDesc = add.getDesc();

		// Verify details of product
		Assert.assertEquals(actTitle, title, "Title not matched.");
		Assert.assertEquals(actSku, sku, "Sku not matched.");
		Assert.assertEquals(actDesc, desc, "Description not matched.");

		log.info("Product Added Successfully with all mandatory fields.");

	}

	@Test(dependsOnMethods = "addNewProductWithMandatoryFields", description = "To check product creation with max length Validation.", enabled = true)
	public void addNewProductWithLengthValidation() throws InterruptedException {

		// redirect to add product page
		AddNewProductPage add = new AddNewProductPage(driver);
		add.redirectToaddProductPage();

		// Creating product with max length validation
		String title = TestUtil.getRandomString(45);
		String sku = TestUtil.getRandomString(15);
		String desc = TestUtil.getRandomString(20);

		add.addProduct(title, sku, desc);

		// Actual values of product from product listing page
		String actTitle = add.getTitle();
		String actSku = add.getSku();
		String actDesc = add.getDesc();

		// Expected values of product
		String expTitle = title.substring(0, 40);
		String expSku = actSku.substring(0, 10);

		Assert.assertEquals(actTitle, expTitle);
		Assert.assertEquals(actSku, expSku);

		// Verify details of product
		Assert.assertEquals(actTitle, expTitle, "Title not matched.");
		Assert.assertEquals(actSku, expSku, "Sku not matched.");
		Assert.assertEquals(actDesc, desc, "Description not matched.");

		log.info("Product Added Successfully with correct length validations.");

	}

	@Test(dependsOnMethods = "addNewProductWithMandatoryFields", description = "To check product creation with uniq Validation.", enabled = true)
	public void addNewProductWithUniqValidation() throws InterruptedException {

		// Captured Actual Product Details from Product List
		ProductListingPage product = new ProductListingPage(driver);
		product.clickOnProductLink();
		String Title = product.getListTitle();
		String Sku = product.getListSku();
		String Desc = product.getListDesc();

		// redirect to add product page
		AddNewProductPage add = new AddNewProductPage(driver);
		add.redirectToaddProductPage();

		// Creating product with duplicate details
		add.addProduct(Title, Sku, Desc);

		// Actual Validation messages for uniq fields
		String expMsg = "has already been taken";

		String actTitleValMsg = add.validateUniqTitleErrorMsg();
		String actSkuValMsg = add.validateUniqSkuErrorMsg();

		// Verify details of product
		Assert.assertEquals(actTitleValMsg, expMsg, "There is no unique validation to Title");
		Assert.assertEquals(actSkuValMsg, expMsg, "There is no unique validation to Sku");

		log.info("Title & Sku Uniq Validations verified successfully.");

	}

}
